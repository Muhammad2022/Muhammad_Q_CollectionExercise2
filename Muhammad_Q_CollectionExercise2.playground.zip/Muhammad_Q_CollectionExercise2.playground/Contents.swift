import UIKit

var myCollection = ["I like to collect"]

myCollection.append("caps")
myCollection.append("money")
myCollection += ["keys"]

myCollection.sort()

print(myCollection)
